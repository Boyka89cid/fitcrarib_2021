import 'package:fluro/fluro.dart';
import 'package:fitcarib/utils/prefs.dart';

abstract class BaseListener {
  //Router getRouter();
  Prefs getPrefs();
}

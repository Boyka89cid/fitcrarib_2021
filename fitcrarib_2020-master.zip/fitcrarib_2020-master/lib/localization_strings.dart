const String AppTitle = 'app_title',
    RegisterTitle = 'register_title',
    RegisterButton = 'register_button';

final hi = {
  AppTitle: 'Reached',
  RegisterTitle: 'Registracion',
  RegisterButton: 'Registrar'
};

final en = {
  AppTitle: 'Reached',
  RegisterTitle: 'Sign Up',
  RegisterButton: 'Register'
};

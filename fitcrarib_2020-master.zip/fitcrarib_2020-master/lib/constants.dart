
final String keyToken = "tokenForWbApi";
final String navigateTo = "navigateTo";
final String keyCode = "keyCode";
final String keyDialCode = "keyDialCode";

final bool certificateAllow = true;
final String baseURLStaging = "https://staging.reffero.com/api/";
final String baseURLProduction = "https://reffero.com/api/";
final iv = '8bytesiv';
final key =
    'my32lengthsupersecretnooneknows1dhfjkhsdfhhfd-abcderghijklmnopqrstuvwxyz0123456789-+jhfjdhfjdjfhjdfhjdhfksdhuerwiuekjewriou34872jhdkjkhdfshdksjhfkjsurtjfkghkfjdhuewoijhbvkjsfjdfjasdljuorikjshfkj';
final connectTimeout = 15000;

final List<String> months = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December"
];

import 'package:fitcarib/base/presenter/base_presenter.dart';

abstract class GroupsContract extends BaseContract {

}

class GroupsPresenter extends BasePresenter {
  GroupsPresenter(BaseContract view) : super(view);
}

import 'package:fitcarib/base/presenter/base_presenter.dart';

abstract class ResetPasswordContract extends BaseContract {

}

class ResetPasswordPresenter extends BasePresenter {
  ResetPasswordPresenter(BaseContract view) : super(view);
}

import 'package:fitcarib/base/presenter/base_presenter.dart';

abstract class NewPasswordContract extends BaseContract {

}

class NewPasswordPresenter extends BasePresenter {
  NewPasswordPresenter(BaseContract view) : super(view);
}

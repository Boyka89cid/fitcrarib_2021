import 'package:fitcarib/base/presenter/base_presenter.dart';

abstract class OtpContract extends BaseContract {

}

class OtpPresenter extends BasePresenter {
  OtpPresenter(BaseContract view) : super(view);
}

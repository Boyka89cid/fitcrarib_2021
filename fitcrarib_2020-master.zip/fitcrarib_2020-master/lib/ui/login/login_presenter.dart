import 'package:fitcarib/base/presenter/base_presenter.dart';

abstract class LoginContract extends BaseContract {
  
}

class LoginPresenter extends BasePresenter {
  LoginPresenter(BaseContract view) : super(view);
}

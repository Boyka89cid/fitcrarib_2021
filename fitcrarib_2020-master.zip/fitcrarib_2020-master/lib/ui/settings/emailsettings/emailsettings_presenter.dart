import 'package:fitcarib/base/presenter/base_presenter.dart';

abstract class EmailSettingsContract extends BaseContract {

}

class EmailSettingsPresenter extends BasePresenter {
  EmailSettingsPresenter(BaseContract view) : super(view);
}
